/********************************************************************************
** Form generated from reading UI file 'addalarmdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDALARMDIALOG_H
#define UI_ADDALARMDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddAlarmDialog
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QComboBox *comboBox;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_3;
    QTimeEdit *timeEdit;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *AddAlarmDialog)
    {
        if (AddAlarmDialog->objectName().isEmpty())
            AddAlarmDialog->setObjectName(QString::fromUtf8("AddAlarmDialog"));
        AddAlarmDialog->resize(633, 394);
        AddAlarmDialog->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        layoutWidget = new QWidget(AddAlarmDialog);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 30, 299, 182));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"font-size:20px;"));

        horizontalLayout->addWidget(label);

        lineEdit = new QLineEdit(layoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout->addWidget(lineEdit);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 20px;"));

        horizontalLayout_2->addWidget(label_2);

        comboBox = new QComboBox(layoutWidget);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_2->addWidget(comboBox);


        verticalLayout->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 20px;"));

        horizontalLayout_3->addWidget(label_3);

        timeEdit = new QTimeEdit(layoutWidget);
        timeEdit->setObjectName(QString::fromUtf8("timeEdit"));
        timeEdit->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(timeEdit);


        verticalLayout->addLayout(horizontalLayout_3);

        layoutWidget1 = new QWidget(AddAlarmDialog);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(320, 290, 221, 56));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8(" background-color: blue; \n"
"  border: blue;\n"
"  color: white;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"\n"
"font-size:20px;"));

        horizontalLayout_4->addWidget(pushButton);

        pushButton_2 = new QPushButton(layoutWidget1);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8(" background-color: blue; \n"
"  border: blue;\n"
"  color: white;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"\n"
"font-size:20px;"));

        horizontalLayout_4->addWidget(pushButton_2);

#if QT_CONFIG(shortcut)
        label->setBuddy(lineEdit);
        label_2->setBuddy(comboBox);
        label_3->setBuddy(timeEdit);
#endif // QT_CONFIG(shortcut)

        retranslateUi(AddAlarmDialog);
        QObject::connect(pushButton, SIGNAL(clicked()), AddAlarmDialog, SLOT(accept()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), AddAlarmDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(AddAlarmDialog);
    } // setupUi

    void retranslateUi(QDialog *AddAlarmDialog)
    {
        AddAlarmDialog->setWindowTitle(QCoreApplication::translate("AddAlarmDialog", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("AddAlarmDialog", "Description:", nullptr));
        label_2->setText(QCoreApplication::translate("AddAlarmDialog", "RingTone:", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("AddAlarmDialog", "RingTone1", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("AddAlarmDialog", "RingTone2", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("AddAlarmDialog", "Ring Tone3", nullptr));

        label_3->setText(QCoreApplication::translate("AddAlarmDialog", "Time:", nullptr));
        pushButton->setText(QCoreApplication::translate("AddAlarmDialog", "OK", nullptr));
        pushButton_2->setText(QCoreApplication::translate("AddAlarmDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddAlarmDialog: public Ui_AddAlarmDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDALARMDIALOG_H
