/********************************************************************************
** Form generated from reading UI file 'chronometer.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHRONOMETER_H
#define UI_CHRONOMETER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_chronometer
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLCDNumber *lcdNumber;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_3;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_2;

    void setupUi(QDialog *chronometer)
    {
        if (chronometer->objectName().isEmpty())
            chronometer->setObjectName(QString::fromUtf8("chronometer"));
        chronometer->resize(604, 428);
        chronometer->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        verticalLayout_2 = new QVBoxLayout(chronometer);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        lcdNumber = new QLCDNumber(chronometer);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));

        verticalLayout->addWidget(lcdNumber);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(chronometer);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"font: 20pt \"MS Shell Dlg 2\";"));

        horizontalLayout->addWidget(pushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_3 = new QPushButton(chronometer);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"font: 20pt \"MS Shell Dlg 2\";"));

        horizontalLayout->addWidget(pushButton_3);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_2);

        pushButton_2 = new QPushButton(chronometer);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"font: 20pt \"MS Shell Dlg 2\";"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(chronometer);

        QMetaObject::connectSlotsByName(chronometer);
    } // setupUi

    void retranslateUi(QDialog *chronometer)
    {
        chronometer->setWindowTitle(QCoreApplication::translate("chronometer", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("chronometer", "Start", nullptr));
        pushButton_3->setText(QCoreApplication::translate("chronometer", "Restart", nullptr));
        pushButton_2->setText(QCoreApplication::translate("chronometer", "Stop", nullptr));
    } // retranslateUi

};

namespace Ui {
    class chronometer: public Ui_chronometer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHRONOMETER_H
