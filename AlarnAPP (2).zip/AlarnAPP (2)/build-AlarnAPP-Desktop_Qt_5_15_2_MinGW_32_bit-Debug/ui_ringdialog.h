/********************************************************************************
** Form generated from reading UI file 'ringdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RINGDIALOG_H
#define UI_RINGDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_RingDialog
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QDialog *RingDialog)
    {
        if (RingDialog->objectName().isEmpty())
            RingDialog->setObjectName(QString::fromUtf8("RingDialog"));
        RingDialog->resize(409, 238);
        RingDialog->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        verticalLayout_2 = new QVBoxLayout(RingDialog);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(RingDialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);\n"
"font: 26pt \"MS Shell Dlg 2\";"));

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        pushButton = new QPushButton(RingDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"font: 20pt \"MS Shell Dlg 2\";"));

        horizontalLayout->addWidget(pushButton);

        pushButton_2 = new QPushButton(RingDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"font: 20pt \"MS Shell Dlg 2\";"));

        horizontalLayout->addWidget(pushButton_2);


        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);


        retranslateUi(RingDialog);
        QObject::connect(pushButton, SIGNAL(clicked()), RingDialog, SLOT(accept()));
        QObject::connect(pushButton_2, SIGNAL(clicked()), RingDialog, SLOT(reject()));

        QMetaObject::connectSlotsByName(RingDialog);
    } // setupUi

    void retranslateUi(QDialog *RingDialog)
    {
        RingDialog->setWindowTitle(QCoreApplication::translate("RingDialog", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("RingDialog", "It's time  !!", nullptr));
        pushButton->setText(QCoreApplication::translate("RingDialog", "Stop", nullptr));
        pushButton_2->setText(QCoreApplication::translate("RingDialog", "Repeat", nullptr));
    } // retranslateUi

};

namespace Ui {
    class RingDialog: public Ui_RingDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RINGDIALOG_H
