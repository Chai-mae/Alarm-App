/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QListView *listView;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QPushButton *pushButton_2;
    QLabel *label;
    QPushButton *pushButton_3;
    QLabel *label_2;
    QLCDNumber *lcdNumber;
    QPushButton *pushButton_5;
    QLabel *label_3;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(800, 745);
        Widget->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(0, 0, 0);"));
        listView = new QListView(Widget);
        listView->setObjectName(QString::fromUtf8("listView"));
        listView->setGeometry(QRect(30, 110, 741, 521));
        listView->setMaximumSize(QSize(741, 16777215));
        listView->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);\n"
"font: 26pt \"Franklin Gothic Book\";\n"
"border:none;\n"
""));
        pushButton = new QPushButton(Widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(0, 0, 201, 71));
        pushButton->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 30px;"));
        pushButton_4 = new QPushButton(Widget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(-20, 650, 261, 51));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: none; \n"
"  border: none;\n"
"image: url(:/icons8-temps-64.png);"));
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(650, 10, 151, 61));
        pushButton_2->setStyleSheet(QString::fromUtf8("image: url(:/icons8-plus-64.png);\n"
"background-color: none; \n"
"  border: none;\n"
""));
        label = new QLabel(Widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 690, 191, 61));
        label->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 20px;"));
        pushButton_3 = new QPushButton(Widget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(630, 650, 161, 51));
        pushButton_3->setStyleSheet(QString::fromUtf8("background-color: none; \n"
"  border: none;\n"
"image: url(:/icons8-wireframe-display-modes-64.png);"));
        label_2 = new QLabel(Widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(650, 690, 191, 61));
        label_2->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 20px;"));
        lcdNumber = new QLCDNumber(Widget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setGeometry(QRect(270, 10, 251, 71));
        pushButton_5 = new QPushButton(Widget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(300, 640, 201, 61));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: none; \n"
"  border: none;\n"
"image: url(:/icons8-sablier-64.png);"));
        label_3 = new QLabel(Widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(340, 690, 191, 61));
        label_3->setStyleSheet(QString::fromUtf8(" background-color: none; \n"
"  border: none;\n"
"  color: blue;\n"
"  padding: 15px 32px;\n"
"  text-align: center;\n"
"  text-decoration: none;\n"
"  display: inline-block;\n"
"  font-size: 20px;"));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        pushButton->setText(QCoreApplication::translate("Widget", "Delete", nullptr));
        pushButton_4->setText(QString());
        pushButton_2->setText(QString());
        label->setText(QCoreApplication::translate("Widget", "Chronometer", nullptr));
        pushButton_3->setText(QString());
        label_2->setText(QCoreApplication::translate("Widget", "Clock", nullptr));
        pushButton_5->setText(QString());
        label_3->setText(QCoreApplication::translate("Widget", "Timer", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
