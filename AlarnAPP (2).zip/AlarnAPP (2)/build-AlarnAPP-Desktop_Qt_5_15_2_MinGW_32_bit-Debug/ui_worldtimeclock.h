/********************************************************************************
** Form generated from reading UI file 'worldtimeclock.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORLDTIMECLOCK_H
#define UI_WORLDTIMECLOCK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_WorldTimeClock
{
public:

    void setupUi(QDialog *WorldTimeClock)
    {
        if (WorldTimeClock->objectName().isEmpty())
            WorldTimeClock->setObjectName(QString::fromUtf8("WorldTimeClock"));
        WorldTimeClock->resize(400, 300);
        WorldTimeClock->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));

        retranslateUi(WorldTimeClock);

        QMetaObject::connectSlotsByName(WorldTimeClock);
    } // setupUi

    void retranslateUi(QDialog *WorldTimeClock)
    {
        WorldTimeClock->setWindowTitle(QCoreApplication::translate("WorldTimeClock", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WorldTimeClock: public Ui_WorldTimeClock {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORLDTIMECLOCK_H
