#ifndef WORLDCLOCKK_H
#define WORLDCLOCKK_H
#include<QPaintEvent>
#include<QWidget>


class WorldClockk : public QWidget
{
public:
    WorldClockk();
    void paintEvent(QPaintEvent *event) override;
};

#endif // WORLDCLOCKK_H
