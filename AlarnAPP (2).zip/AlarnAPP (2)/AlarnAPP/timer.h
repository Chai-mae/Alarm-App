#ifndef TIMER_H
#define TIMER_H

#include <QDialog>
#include<QElapsedTimer >
#include<QTimer>
#include<QTime>



namespace Ui {
class Timer;
}

class Timer : public QDialog
{
    Q_OBJECT

public:
    explicit Timer(QWidget *parent = nullptr);
    ~Timer();

private slots:
    void showTime();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::Timer *ui;
    QTime countdown;
    QElapsedTimer etimer;
    QTimer* timer = new QTimer();

};

#endif // TIMER_H
