#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include<QStandardItemModel>
#include<QPushButton>
#include <QTimer>
#include <QMediaPlayer>
#include <QCloseEvent>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
     QPushButton *button;
     QTimer *timer = new QTimer(this) ;
     QTimer *timer1 = new QTimer(this) ;
     QMediaPlayer *ring= new QMediaPlayer();
protected:
void load(QString);


private slots:
    void on_pushButton_2_clicked();
    void showTime();


    void on_pushButton_4_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_clicked();

protected:
    void closeEvent(QCloseEvent* e) override;

private:
    Ui::Widget *ui;
    QStandardItemModel *model;
    QStandardItem *item;
    QStringList l;
    QString currentFile;

};
#endif // WIDGET_H
