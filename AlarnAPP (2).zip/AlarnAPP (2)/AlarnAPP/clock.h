#ifndef CLOCK_H
#define CLOCK_H

#include <QWidget>

class clock : public QWidget
{
    Q_OBJECT
public:
    explicit clock(QWidget *parent = nullptr);

signals:

};

#endif // CLOCK_H
