#include "clock.h"
#include <QtUiTools>

clock::clock(QWidget *parent) : QWidget(parent)
{

    Q_INIT_RESOURCE(worldtimeclockbuilder);



        QUiLoader loader;
        QFile file(":/forms/form.ui");
            file.open(QFile::ReadOnly);

            QWidget *widget = loader.load(&file);

            file.close();
            widget->show();
}
