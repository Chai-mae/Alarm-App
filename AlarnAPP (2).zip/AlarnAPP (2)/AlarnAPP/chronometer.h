#ifndef CHRONOMETER_H
#define CHRONOMETER_H

#include <QDialog>
#include<QTimer>

namespace Ui {
class chronometer;
}

class chronometer : public QDialog
{
    Q_OBJECT

public:
    explicit chronometer(QWidget *parent = nullptr);
    ~chronometer();
     QTimer *timer = new QTimer(this) ;

private slots:
     void on_pushButton_clicked();

     void on_pushButton_3_clicked();

     void on_pushButton_2_clicked();
      void showTime();

private:
    Ui::chronometer *ui;
    QTime *chrono;

};

#endif // CHRONOMETER_H
