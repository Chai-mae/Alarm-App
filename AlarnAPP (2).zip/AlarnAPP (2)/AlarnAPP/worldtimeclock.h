#ifndef WORLDTIMECLOCK_H
#define WORLDTIMECLOCK_H

#include <QDialog>
#include<QPaintEvent>
#include<QWidget>


namespace Ui {
class WorldTimeClock;
}

class WorldTimeClock : public QDialog
{
    Q_OBJECT

public:
    explicit WorldTimeClock(QWidget *parent = nullptr);
    ~WorldTimeClock();
    void paintEvent(QPaintEvent *event) override;

private:
    Ui::WorldTimeClock *ui;

};

#endif // WORLDTIMECLOCK_H
