#include "timer.h"
#include "ui_timer.h"
#include<QTime>



Timer::Timer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Timer)
{
    ui->setupUi(this);
    etimer.start();


     ui->lcdNumber->setDigitCount(11);



    setWindowTitle("Timer");
}

Timer::~Timer()
{
    delete ui;
}

void Timer::showTime(){
    countdown = ui->timeEdit->time();
    auto elapsed =etimer.elapsed();
      auto c=countdown.addMSecs(-elapsed);
      QString timestr = c.toString("hh:mm:ss.zzz");
      ui->lcdNumber->display(timestr);
}

void Timer::on_pushButton_2_clicked()
{
     ui->lcdNumber->display(ui->timeEdit->text());
    connect(timer, &QTimer::timeout,this, &Timer::showTime);

     timer->start();

}


void Timer::on_pushButton_3_clicked()
{

    int remaining =timer->remainingTime();
    timer->stop();
    timer->setInterval(remaining);

}


void Timer::on_pushButton_4_clicked()
{



    timer->start();

}

