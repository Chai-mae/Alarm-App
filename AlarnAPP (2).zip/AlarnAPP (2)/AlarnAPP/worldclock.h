#ifndef WORLDCLOCK_H
#define WORLDCLOCK_H

#include <QWidget>

class WorldClock : public QWidget
{
    Q_OBJECT
public:
    explicit WorldClock(QWidget *parent = nullptr);

signals:

};

#endif // WORLDCLOCK_H
