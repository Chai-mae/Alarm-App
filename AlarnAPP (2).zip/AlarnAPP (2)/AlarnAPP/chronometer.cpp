#include "chronometer.h"
#include "ui_chronometer.h"
#include<QTime>
int h=0;
int m=0;
int s=0;
chronometer::chronometer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::chronometer)
{
    ui->setupUi(this);
    ui->lcdNumber->setDigitCount(8);
    chrono = new QTime(0,0,0);
 ui->lcdNumber->display(chrono->toString());

    connect(timer,&QTimer::timeout,this,&chronometer::showTime);

    setWindowTitle("Chronometer");
}

chronometer::~chronometer()
{
    delete ui;
}

void chronometer::on_pushButton_clicked()
{
 timer->start(1000);


}


void chronometer::on_pushButton_3_clicked()
{
 s=0;
 timer->start(1000);
}


void chronometer::on_pushButton_2_clicked()
{

    timer->stop();
}
void chronometer::showTime(){
    chrono = new QTime(h,m,s);


 ui->lcdNumber->display(chrono->toString());
 s++;

 if(s > 59) {
      m++;
      s = 0;
    }

    if(m> 59) {
      h++;
      s = 0;
      m= 0;
    }

 }








