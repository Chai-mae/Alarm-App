#ifndef ADDALARMDIALOG_H
#define ADDALARMDIALOG_H

#include <QDialog>

namespace Ui {
class AddAlarmDialog;
}

class AddAlarmDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddAlarmDialog(QWidget *parent = nullptr);
    ~AddAlarmDialog();

    QString getTimeSting();
    QString getRingTone();
    QString getDesc();
    QTime getTime();

//    void setDescription(QString);
//    void setDate(QString);
//    void setTag(QString);
//    void setFinished(bool);

private:
    Ui::AddAlarmDialog *ui;
};

#endif // ADDALARMDIALOG_H
