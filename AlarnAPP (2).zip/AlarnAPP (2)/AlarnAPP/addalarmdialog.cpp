#include "addalarmdialog.h"
#include "ui_addalarmdialog.h"

AddAlarmDialog::AddAlarmDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddAlarmDialog)
{
    ui->setupUi(this);
     QTime time = QTime::currentTime();
      ui->timeEdit->setTime(time);

      setWindowTitle("Add Alarm");
}

AddAlarmDialog::~AddAlarmDialog()
{
    delete ui;
}
QString AddAlarmDialog::getDesc(){
    return ui->lineEdit->text();

}
QString AddAlarmDialog::getTimeSting(){
    return ui->timeEdit->text();
}
QString AddAlarmDialog::getRingTone(){
    return ui->comboBox->currentText();
}
QTime AddAlarmDialog::getTime(){
    return ui->timeEdit->time() ;
}
