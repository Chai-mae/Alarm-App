#include "widget.h"
#include "ui_widget.h"
#include "addalarmdialog.h"
#include<QPixmap>
#include<QCheckBox>
#include<QPushButton>
#include<QTime>
#include"chronometer.h"
#include"ringdialog.h"
#include <QtUiTools>
#include<QMediaPlayer>
#include<QDebug>
#include<QModelIndex>
#include<iostream>
#include"timer.h"
#include"worldtimeclock.h"


Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    model = new QStandardItemModel(this);
    QFile file("currentFile.txt");

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
          return;

    while (!file.atEnd()) {
        QString line = file.readLine();
        if(line.isEmpty()){

        }else{
        item = new QStandardItem();
        item->setText(line.mid(1,line.size()-1));
        if(line.at(0)=="1"){
            item->setCheckable( true );
            item->setCheckState( Qt::Checked );
        }else if(line.at(0)=="0"){
            item->setCheckable( true );
            item->setCheckState( Qt::Unchecked);
        }else{
            continue;
        }



        model->appendRow(item);
        ui->listView->setModel(model);
        }
    }

    setWindowTitle("Alarm");

connect(timer,&QTimer::timeout,this,&Widget::showTime);
timer->start(1000);
 ui->listView->setModel(model);





}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_2_clicked()
{
    AddAlarmDialog dialog;
      auto reply=dialog.exec();
      if (reply==AddAlarmDialog::Accepted)
      {


         item = new QStandardItem();

//         QStandardItem::indicator {
//             width: 13px;
//             height: 13px;
//         }
//         QStandardItem->setStyleSheet(
//            " QListView::indicator:checked:enabled {
//                     image: url(:/toggle.png);
//              }
//             QStandardItem::indicator:unchecked:enabled {
//                      image: url(:/Toff.png);
//} "
//);



          item->setText(dialog.getTimeSting()+" "+dialog.getDesc()+" "+dialog.getRingTone());


          item->setCheckable( true );
         item->setCheckState( Qt::Checked );


          model->appendRow(item);


             ui->listView->setModel(model);
      }
}

void Widget::showTime(){

    QTime t =  QTime::currentTime();
    QString text = t.toString("hh:mm");
    ui->lcdNumber->display(text);


    RingDialog d ;
    for(int i=0; i<model->rowCount(); i++){
        QString s=model->item(i)->text();
        QStringList list = s.split(" ");

    if(model->item(i)->checkState() && text==list[0] ){
        timer->start(60000);

        if(list[2]== "RingTone1"){
            ring->setMedia(QUrl("qrc:/ring1.mp3"));
            ring->play();

        }
        else if (list[2]== "RingTone2"){
            ring->setMedia(QUrl("qrc:/ring2.mp3"));
            ring->play();
        }
        else{
            ring->setMedia(QUrl("qrc:/ring3.mp3"));
            ring->play();
        }
        auto reply=d.exec();
        if (reply==RingDialog::Accepted)
        {

            ring->stop();

        }
        else if (reply==RingDialog::Rejected) {
            ring->stop();
            QStringList list2= list[0].split(":");
            int a=list2[1].toInt()+1;
            QString b= QString::number(a);
            l.append(list2[0]+":"+b+" "+list[1]+" "+list[2]);


        }

    }
}
  for(int i=0;i<l.size();i++){

      QStringList list3= l[i].split(" ");
      qDebug()<<list3[0];
      if(text==list3[0]){
          std::cout<<"test";
          if(list3[2]== "RingTone1"){
              ring->setMedia(QUrl("qrc:/ring1.mp3"));
              ring->play();

          }
          else if (list3[2]== "RingTone2"){
              ring->setMedia(QUrl("qrc:/ring2.mp3"));
              ring->play();
          }
          else{
              ring->setMedia(QUrl("qrc:/ring3.mp3"));
              ring->play();
          }
          auto reply=d.exec();
          if (reply==RingDialog::Accepted)
          {

              ring->stop();
              l.removeAt(i);
          }
          else if (reply==RingDialog::Rejected) {
              ring->stop();
              QStringList list2= list3[0].split(":");
              int a=list2[1].toInt()+1;
              QString b= QString::number(a);
              l.removeAt(i);
              l.append(list2[0]+":"+b+" "+list3[1]+" "+list3[2]);


      }
  }

}
}

void Widget::on_pushButton_4_clicked()
{
    chronometer chrono;
    chrono.exec();
}


void Widget::on_pushButton_3_clicked()
{

    WorldTimeClock wc;
    wc.exec();

}


void Widget::on_pushButton_5_clicked()
{
   Timer t;
   t.exec();
}

void Widget::closeEvent(QCloseEvent* e){
    QFile file("currentFile.txt");
    if(file.open(QIODevice::ReadWrite | QIODevice::Text)){
        QTextStream out(&file);
        for(int i=0; i<model->rowCount(); i++){
            if(model->item(i)->text().at(0)==" "){

            }else if(model->item(i)->checkState()){
                out<<"1"<<model->item(i)->text()<<Qt::endl;
            }else{
                out<<"0"<<model->item(i)->text()<<Qt::endl;
            }
        }
        file.close();
    }
}
void Widget::on_pushButton_clicked()
{
    model->removeRow(ui->listView->currentIndex().row());
    ui->listView->setModel(model);

}


