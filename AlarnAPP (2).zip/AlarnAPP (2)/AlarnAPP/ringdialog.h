#ifndef RINGDIALOG_H
#define RINGDIALOG_H

#include <QDialog>

namespace Ui {
class RingDialog;
}

class RingDialog : public QDialog
{
    Q_OBJECT

public:
    explicit RingDialog(QWidget *parent = nullptr);
    ~RingDialog();

private:
    Ui::RingDialog *ui;
};

#endif // RINGDIALOG_H
