#include "ringdialog.h"
#include "ui_ringdialog.h"

RingDialog::RingDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RingDialog)
{
    ui->setupUi(this);
    setWindowTitle("Alarm");
}

RingDialog::~RingDialog()
{
    delete ui;
}
