#include "worldclock.h"
 #include <QtUiTools>
#include<QApplication>

WorldClock::WorldClock(QWidget *parent) : QWidget(parent)
{
    Q_INIT_RESOURCE(worldtimeclockbuilder);


       QUiLoader loader;
    QFile file(":/forms/form.ui");
        file.open(QFile::ReadOnly);

        QWidget *widget = loader.load(&file);

        file.close();
        widget->show();

}

